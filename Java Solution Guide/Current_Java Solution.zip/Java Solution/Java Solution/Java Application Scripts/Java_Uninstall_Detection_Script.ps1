﻿## Enter the version code of the current Java deployment.  Keep this updated for any new Java deployments ##
$CurrentVersion = "1.8.0_45"

# 64-bit OS
if ((Get-WmiObject -Class win32_operatingsystem | Select OSArchitecture).OSArchitecture -eq "64-bit")
    {
        $pathx86 = "HKLM:\SOFTWARE\Wow6432Node\JavaSoft\Java Runtime Environment"
        $pathx64 = "HKLM:\SOFTWARE\JavaSoft\Java Runtime Environment"

                # Do any other 64-bit versions exist?
                    try
                        {
                            $items = Get-ChildItem $pathx64 -ErrorAction SilentlyContinue
                            $count = 0
                            if ($items -ne $null)
                                {
                                    foreach ($item in $items)
                                        {
                                            if ($item.Name -notmatch $CurrentVersion -and $item.SubKeyCount -notmatch "0")
                                            {$count += 1}
                                        }
                                }
                            else
                                # If reg key doesn't exist, we don't need to uninstall anything there, so we are compliant in the 64-bit Java version.
                                {$64bitCompliant = $true}
                        }
                    catch
                        # If reg key doesn't exist, we don't need to uninstall anything there, so we are compliant in the 64-bit Java version.
                        { $64bitCompliant = $true }
                    if ($Count -ne 0)
                        # If there are subkeys that do not match the current version, then we are not compliant in the 64-bit registry
                        { $64bitCompliant = $false }
                    else
                        # If there are no subkeys other than the current version, then we are compliant in the 64-bit registry
                        { $64bitCompliant = $true }

                # Do any other 32-bit versions exist?
                    try
                        {
                            $items = Get-ChildItem $pathx86 -ErrorAction SilentlyContinue
                            $count = 0
                            if ($items -ne $null)
                                {
                                    foreach ($item in $items)
                                        {
                                            if ($item.Name -notmatch $CurrentVersion -and $item.SubKeyCount -notmatch "0")
                                                {$count += 1}
                                        }
                                }
                            else
                                # If there are no subkeys then we are compliant in the 32-bit registry
                                { $32bitCompliant = $true }
                        }
                    catch
                        # If reg key doesn't exist, we don't need to uninstall anything there, so we are compliant in the 32-bit Java version.
                            { $32bitCompliant = $true }
                    if ($Count -ne 0)
                        # If there are subkeys that do not match the current version, then we are not compliant in the 32-bit registry
                            { $32bitCompliant = $false }
                    else
                        # If there are no subkeys other than the current version, then we are compliant in the 32-bit registry
                            { $32bitCompliant = $true }
           # }
        
        if ($64bitCompliant -eq $true -and $32bitCompliant -eq $true)
            { write-host "Compliant" }
        else
            {}
    }
# 32-bit OS
else
    {
        $path = "HKLM:\SOFTWARE\JavaSoft\Java Runtime Environment"

            # Do any other 32-bit versions exist?
                try
                    {
                        $items = Get-ChildItem $path -ErrorAction SilentlyContinue
                        $count = 0
                        if ($items -ne $null)
                            {
                                foreach ($item in $items)
                                    {
                                        if ($item.Name -notmatch $CurrentVersion -and $item.SubKeyCount -notmatch "0")
                                            {$count += 1}
                                    }
                            }
                        else
                            # If there are no subkeys then we are compliant in the 32-bit registry
                            { write-host "Compliant" }
                    }
                catch
                    # If reg key doesn't exist, we don't need to uninstall anything there, so we are compliant in the 32-bit Java version.
                    { write-host "Compliant" }
                if ($Count -ne 0)
                    # If there are subkeys that do not match the current version, then we are not compliant in the 32-bit registry
                    {}
                else
                    # If there are no subkeys other than the current version, then we are compliant in the 32-bit registry
                    { write-host "Compliant" }
    }