﻿<#

.SYNOPSIS
    Updates the Java Application with the latest Java version

.DESCRIPTION
    This script can be used to update the Java applications to the latest Java version.  The following activities are performed:
    - Any existing deployment type named "Old*" will be deleted
    - The existing INSTALL deployment type will be renamed to "Old_*", and a dummy requirement set for Total Physical Memory of 9MB to disable it
    - The deadline on the existing deployments will be set to the distant future to disable them during the update of the application
    - A check for the binaries in the PackageSource will be done, and if not found, they will be downloaded, the MSI extracted and copied to the PackageSource
    - A new INSTALL deployment type will be created and dependencies and requirements added where applicable
    - The deployment type priorities will be reordered so that the new INSTALL DT evaluates first
    - A new deadline will be set for the deployment

.PARAMETER x64
    Use this switch to indicate you want to update the Java deployment for the "Java (x64)" application

.PARAMETER ApplicationName
    The name of the Application you want to update

.PARAMETER TargetedCollection
    The name of the collection targeted by the application deployment

.PARAMETER DeployDeadlineDate
    The date of the new deadline for the deployment

.PARAMETER DeployDeadlineTime
    The time of the new deadline for the deployment

.PARAMETER JavaPackageSourceLocal
    The local path on the server to the Java package source directory, eg G:\PackageSource\Java

.PARAMETER JavaPackageSourceRemote
    The remote UNC path to the same Java package source directory, eg \\sccmsrv-01\PackageSource\Java

.EXAMPLE
    .\New-JavaDeployment.ps1 -ApplicationName "Java" -TargetedCollection "All SCCM 2012 Clients" -DeployDeadlineDate 22/06/2016 -DeployDeadlineTime 15:00
    This will create a new deployment type of the latest Java release for the application "Java".  The deadline of the deployment targeted to the "All SCCM 2012 Clients" collection will be 
    updated to the new date and time specified.  The default PackageSource locations will be used.

.EXAMPLE
    .\New-JavaDeployment.ps1 -x64 -ApplicationName "Java (x64)" -TargetedCollection "All SCCM 2012 Clients" -DeployDeadlineDate 22/06/2016 -DeployDeadlineTime 15:00
    This will create a new deployment type of the latest 64-bit Java release for the application "Java (x64)".  The deadline of the deployment targeted to the "All SCCM 2012 Clients" collection 
    will be updated to the new date and time specified.  The default PackageSource locations will be used.

.NOTES
    Script name: New-JavaDeployment.ps1
    Author:      Trevor Jones
    Contact:     @trevor_smsagent
    DateCreated: 2015-05-27
    Link:        http://smsagent.wordpress.com

#>


[CmdletBinding(SupportsShouldProcess=$True)]
    param
        (
        [Parameter(Mandatory=$True)]
            [string]$ApplicationName,
        [parameter(Mandatory=$True)]
            [string]$TargetedCollection,
        [parameter(Mandatory=$True)]
            [string]$DeployDeadlineDate,
        [parameter(Mandatory=$True)]
            [string]$DeployDeadlineTime,
        [parameter(Mandatory=$False)]
            [switch]$x64,
        [parameter(Mandatory=$False)]
            [string]$JavaPackagesourceLocal="G:\PackageSource\Java" ,
        [parameter(Mandatory=$False)]
            [string]$JavaPackageSourceRemote="\\sccmsrv-01\PackageSource\Java"
        )


# Change the scope of the variables to global - useful for troubleshooting
$Variables = @(
    "ApplicationName",
    "TargetedCollection",
    "DeployDeadlineDate",
    "DeployDeadlineTime",
    "x64",
    "JavaPackagesourceLocal",
    "JavaPackageSourceRemote"
    )

Foreach ($variable in $variables)
    {Set-Variable -Name $variable -Scope Global}


$ErrorActionPreference = "Stop"


#region Initial Stuff
# Test whether running as admin
If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`
    [Security.Principal.WindowsBuiltInRole] "Administrator"))
{
    Write-Warning "This script must be run elevated!`nPlease re-run as an Administrator!"
    Break
}

# Import ConfigMgr module
import-module ($Env:SMS_ADMIN_UI_PATH.Substring(0,$Env:SMS_ADMIN_UI_PATH.Length-5) + '\ConfigurationManager.psd1')
$script:PSD = Get-PSDrive -PSProvider CMSite
CD "$($PSD):"

# Get Site server name
$script:SiteServer = $PSD.SiteServer
#endregion


cls
write-host "#######################"
write-host "# New Java Deployment #"
write-host "#######################"
write-host ""


#region functions

Function Get-SCCMApplication($name,$siteServerName){
    $connectionManager = new-object Microsoft.ConfigurationManagement.ManagementProvider.WqlQueryEngine.WqlConnectionManager  
    $isConnected = $connectionManager.Connect($siteServerName)
	
	$SCCMserver = $connectionManager.NamedValueDictionary.ServerName
    $SCCMsitecode = $connectionManager.NamedValueDictionary.ConnectedSiteCode
	
    $result = @()
    
    $applications = Get-WmiObject -class SMS_Application -filter "LocalizedDisplayName='$name' AND IsEnabled='True' And IsExpired='False' And IsLatest='True'" -Namespace "root\sms\site_$SCCMsitecode" -ComputerName $SCCMserver
    foreach($application in $applications) {
          $appplicationXML = ([wmi] $application.__Path).SDMPackageXML
          $result += [Microsoft.ConfigurationManagement.ApplicationManagement.Serialization.SccmSerializer]::DeserializeFromString($appplicationXML)
    }
    return $result
 }

Function Save-SCCMApplication($app,$siteServerName){
    $connectionManager = new-object Microsoft.ConfigurationManagement.ManagementProvider.WqlQueryEngine.WqlConnectionManager  
    $isConnected = $connectionManager.Connect($siteServerName)
	$SCCMserver = $connectionManager.NamedValueDictionary.ServerName
    $SCCMsitecode = $connectionManager.NamedValueDictionary.ConnectedSiteCode
	
	$xml = [Microsoft.ConfigurationManagement.ApplicationManagement.Serialization.SccmSerializer]::Serialize($app)
    $applications = Get-WmiObject -class SMS_Application -filter "LocalizedDisplayName='$($app.DisplayInfo.Title)' AND IsEnabled='True' And IsExpired='False' And IsLatest='True'" -Namespace "root\sms\site_$SCCMsitecode" -ComputerName $SCCMserver

    foreach($application in $applications) {
           $applicationUpdate = [wmi] $application.__Path
           $applicationUpdate.SDMPackageXML = $xml 
           $applicationUpdate.Put() | Out-Null

      }
 }

Function Get-SCCMGlobalCondition($name,$siteServerName){
    $connectionManager = new-object Microsoft.ConfigurationManagement.ManagementProvider.WqlQueryEngine.WqlConnectionManager  
    $isConnected = $connectionManager.Connect($siteServerName)
	$SCCMserver = $connectionManager.NamedValueDictionary.ServerName
    $SCCMsitecode = $connectionManager.NamedValueDictionary.ConnectedSiteCode
	$SCCMNamespace = "root\sms\site_$SCCMsitecode" 
    $nameformated = $name.Replace(" ","")
    $objResult = Get-WmiObject -Class SMS_GlobalCondition -Namespace $SCCMNamespace -filter "ModelName like '%$nameformated%' "
    if($objResult -eq $null){       
        $objResult = Get-WmiObject -Class SMS_GlobalCondition -Namespace $SCCMNamespace -filter "ModelName = '$nameformated'"
    }
    if($objResult -eq $null){       
        $objResult = Get-WmiObject -Class SMS_GlobalCondition -Namespace $SCCMNamespace -filter "LocalizedDisplayName = '$nameformated'"
    }
    $objResult
 }

Function Create-SCCMGlobalConditionsRule($siteServerName, $GlobalCondition,$Operator, $Value,$SettingSourceType){
    if($GlobalCondition.ModelName -eq $null){
        $GlobalCondition = Get-SCCMGlobalCondition $GlobalCondition $siteServerName
    }

    if($GlobalCondition -eq $null){
        Write-Error "Global condition not found"
		return
    }

    $gcTmp =  $GlobalCondition.ModelName.Split("/")
    $gcScope = $gcTmp[0]
    $gcLogicalName = $gcTmp[1]
    $gcDataType = $GlobalCondition.DataType
    $gcExpressionDataType = [Microsoft.SystemsManagementServer.DesiredConfigurationManagement.Expressions.DataType]::GetDataTypeFromTypeName($gcDataType)
   
	if($operator.ToLower() -eq  "notexistential" -OR $operator.ToLower() -eq  "existential" ){
		$gcExpressionDataType = [Microsoft.SystemsManagementServer.DesiredConfigurationManagement.Expressions.DataType]::Int64
	}
    #Retrieving logical name of setting 
	$settingsxml = [xml] ([wmi] $GlobalCondition.__PATH).SDMPackageXML
	if(  $settingsxml.DesiredConfigurationDigest.GlobalSettings.AuthoringScopeId -eq "GLOBAL"){
		$SettingLogicalName =  "$($gcLogicalName)_Setting_LogicalName"
	}else{
		$SettingLogicalName = $settingsxml.DesiredConfigurationDigest.GlobalSettings.Settings.FirstChild.FirstChild.LogicalName
	}
	
	#Checking for ConfigurationItemSetting 
	if ($SettingSourceType -ne $null -AND $SettingSourceType -ne "")	{
		$CISettingSourceType = [Microsoft.ConfigurationManagement.DesiredConfigurationManagement.ConfigurationItemSettingSourceType]::$SettingSourceType
	}else{
		$CISettingSourceType = [Microsoft.ConfigurationManagement.DesiredConfigurationManagement.ConfigurationItemSettingSourceType]::CIM
	}
    $arg = @($gcScope, 
              $gcLogicalName, 
              $gcExpressionDataType, 
              $SettingLogicalName, 
              $CISettingSourceType
             )
    $reqSetting =  new-object  Microsoft.SystemsManagementServer.DesiredConfigurationManagement.Expressions.GlobalSettingReference -ArgumentList  $arg
 
    #custom properties Existential
	if($operator.ToLower() -eq  "notexistential"){
		$operator = "Equals"
		$Value = 0
		$reqSetting.MethodType = "Count"
	}
	if($operator.ToLower() -eq  "existential"){
		$operator = "NotEquals"
		$Value = 0
		$reqSetting.MethodType = "Count"
	}

    $arg = @( $value,
               $gcExpressionDataType
             )
    $reqValue = new-object Microsoft.SystemsManagementServer.DesiredConfigurationManagement.Expressions.ConstantValue -ArgumentList $arg

    $operands = new-object "Microsoft.ConfigurationManagement.DesiredConfigurationManagement.CustomCollection``1[[Microsoft.SystemsManagementServer.DesiredConfigurationManagement.Expressions.ExpressionBase]]"
    $operands.Add($reqSetting) | Out-Null
    $operands.Add($reqValue) | Out-Null
 
	#Changing Equals to IsEquals 
	if($operator.ToLower() -eq "equals"){$operator = "IsEquals"}
    $Expoperator =  Invoke-Expression [Microsoft.ConfigurationManagement.DesiredConfigurationManagement.ExpressionOperators.ExpressionOperator]::$operator
    

    if( $GlobalCondition.DataType -eq "OperatingSystem"){
    
        $operands = new-object "Microsoft.ConfigurationManagement.DesiredConfigurationManagement.CustomCollection``1[[Microsoft.SystemsManagementServer.DesiredConfigurationManagement.Expressions.RuleExpression]]"
        foreach( $os in $value){
            $operands.Add($os)
        }
        $arg = @( $Expoperator , 
            $operands
        )
        $expression = new-object Microsoft.SystemsManagementServer.DesiredConfigurationManagement.Expressions.OperatingSystemExpression -ArgumentList $arg
    
    }else{
        $arg = @( $Expoperator , 
            $operands
        )
        $expression = new-object Microsoft.SystemsManagementServer.DesiredConfigurationManagement.Expressions.Expression -ArgumentList $arg
    
    }

    
    $anno =  new-object Microsoft.SystemsManagementServer.DesiredConfigurationManagement.Rules.Annotation 
    $annodisplay = "$GlobalCondition $operator $value"
    $arg = @(
                "DisplayName", 
                $annodisplay, 
                $null
            )
    $anno.DisplayName = new-object Microsoft.SystemsManagementServer.DesiredConfigurationManagement.Rules.LocalizableString -ArgumentList $arg
    
    $arg = @(
                 ("Rule_" + [Guid]::NewGuid().ToString()), 
                 [Microsoft.SystemsManagementServer.DesiredConfigurationManagement.Rules.NoncomplianceSeverity]::None, 
                 $anno, 
                 $expression
            )
    $rule = new-object "Microsoft.SystemsManagementServer.DesiredConfigurationManagement.Rules.Rule" -ArgumentList $arg

    return $rule
 }

function Re-OrderDTPriority()
{
#import assemblies
[System.Reflection.Assembly]::LoadFrom(“C:\Program Files (x86)\Microsoft Configuration Manager\AdminConsole\bin\Microsoft.ConfigurationManagement.ApplicationManagement.dll”) | Out-Null
[System.Reflection.Assembly]::LoadFrom(“C:\Program Files (x86)\Microsoft Configuration Manager\AdminConsole\bin\Microsoft.ConfigurationManagement.ApplicationManagement.Extender.dll”) | Out-Null
[System.Reflection.Assembly]::LoadFrom(“C:\Program Files (x86)\Microsoft Configuration Manager\AdminConsole\bin\Microsoft.ConfigurationManagement.ApplicationManagement.MsiInstaller.dll”) | Out-Null

#Creating Type Accelerators - for making assembly references easier later
$accelerators = [PSObject].Assembly.GetType('System.Management.Automation.TypeAccelerators')
$accelerators::Add('SccmSerializer',[type]'Microsoft.ConfigurationManagement.ApplicationManagement.Serialization.SccmSerializer')

$server = $SiteServer
$code = $PSD

#get the instance of the application
$app = [wmi](gwmi -ComputerName $server -Namespace root\sms\site_$code -class sms_application | ?{$_.LocalizedDisplayName -eq $ApplicationName -and $_.IsLatest -eq $true}).__Path

#deserialize the XML data
$appXML = [SccmSerializer]::DeserializeFromString($app.SDMPackageXML,$true)

# Re-order DT Priorities

    if($appXML.DeploymentTypes.Count -gt 1)
    {    
        $reorderedDT = new-object "Microsoft.ConfigurationManagement.ApplicationManagement.NamedObjectCollection``1[[Microsoft.ConfigurationManagement.ApplicationManagement.DeploymentType]]"
 
        for($i=$appXML.DeploymentTypes.Count-1; $i -ge 0; $i--)
        {
            #Inverse DT Priority on the firs two DTs
            $temp = $appXML.DeploymentTypes[$i]
            $appXML.DeploymentTypes.Remove($temp)
            $reorderedDT.Add( $temp )            
        }
 
        $appXML.DeploymentTypes = $reorderedDT
    }

$newappXML = [Microsoft.ConfigurationManagement.ApplicationManagement.Serialization.SccmSerializer]::Serialize($appXML, $false)
$app.SDMPackageXML = $newappxml
$app.Put() | Out-Null
}

function AdditionalAppUpdates()
{
#import assemblies
[System.Reflection.Assembly]::LoadFrom(“C:\Program Files (x86)\Microsoft Configuration Manager\AdminConsole\bin\Microsoft.ConfigurationManagement.ApplicationManagement.dll”) | Out-Null
[System.Reflection.Assembly]::LoadFrom(“C:\Program Files (x86)\Microsoft Configuration Manager\AdminConsole\bin\Microsoft.ConfigurationManagement.ApplicationManagement.Extender.dll”) | Out-Null
[System.Reflection.Assembly]::LoadFrom(“C:\Program Files (x86)\Microsoft Configuration Manager\AdminConsole\bin\Microsoft.ConfigurationManagement.ApplicationManagement.MsiInstaller.dll”) | Out-Null

#Creating Type Accelerators - for making assemlby refrences easier later
$accelerators = [PSObject].Assembly.GetType('System.Management.Automation.TypeAccelerators')
$accelerators::Add('SccmSerializer',[type]'Microsoft.ConfigurationManagement.ApplicationManagement.Serialization.SccmSerializer')

$server = $SiteServer
$code = $PSD

#get the instance of the application
$app = [wmi](gwmi -ComputerName $server -Namespace root\sms\site_$code -class sms_application | ?{$_.LocalizedDisplayName -eq $ApplicationName -and $_.IsLatest -eq $true}).__Path

#deserialize the XML data
$appXML = [SccmSerializer]::DeserializeFromString($app.SDMPackageXML,$true)

# Find the old deployment type
$array = @()
foreach($dt in $appXML.DeploymentTypes | Where-Object {$_.Title -like "Old*"})
  {
    $number = $dt.Title.Substring(18,2) | Out-String
    $array += $number
  }
$max = ($array | Measure -Maximum).Maximum

#Find the old deployment type number
$i = -1
do
  {
    $i = $i + 1
    $AppDT = $appXML.DeploymentTypes[$i].Title
  }
until ($AppDT -like "*$max*")
$OldMajorVersion = $appdt.Split(" ")[1]

#Find the "uninstall" or "prepare" deployment type number
if ($x64)
    {
        $ii = -1
        do
            {
                $ii = $ii + 1
                $AppDT = $appXML.DeploymentTypes[$ii].Title
            }
        until ($AppDT -like "Prepare*")
    }
Else
    {
        $ii = -1
        do
            {
                $ii = $ii + 1
                $AppDT = $appXML.DeploymentTypes[$ii].Title
            }
        until ($AppDT -like "Uninstall*")
    }

#Find the new deployment type number
$iii = -1
do
  {
    $iii = $iii + 1
    $AppDT = $appXML.DeploymentTypes[$iii].Title
  }
until ($AppDT -match "$minorversion")

# Replace current version in detection script
$newscript = $appXML.DeploymentTypes[$ii].Installer.DetectionScript.Text.Replace(".$OldMajorVersion.0_$max", ".$majorversion.0_$minorversion")
$appXML.DeploymentTypes[$ii].Installer.DetectionScript.Text = $newscript

# Update the 'SourceUpdateProductCode'
$appXML.DeploymentTypes[$iii].Installer.SourceUpdateProductCode = $appXML.DeploymentTypes[$iii].Installer.ProductCode

# Clone the dependency from the old DT to the new one (slightly cheating I guess, but works)
$temp = $appxml.DeploymentTypes[$i].Dependencies.Clone()
$appXML.DeploymentTypes[$iii].Dependencies.CopyFrom($temp)

if ($x64)
    {
        # Clone the 64-bit requirement from the "prepare" DT to the new one
        $temprq = $appXML.DeploymentTypes[$ii].Requirements.Clone() 
        $appXML.DeploymentTypes[$iii].Requirements.CopyFrom($temprq)
    }

#Set the LogonRequirementBehaviour to 'whetherornotuserloggedin'
$appXML.DeploymentTypes[$iii].Installer.RequiresLogOn = $null

# Reserialize and update app
$newappXML = [Microsoft.ConfigurationManagement.ApplicationManagement.Serialization.SccmSerializer]::Serialize($appXML, $false)
$app.SDMPackageXML = $newappxml
$app.Put() | Out-Null
}
 #endregion Functions

 
#region DisableCurrentDP/DPT


################################
## DELETE OLD DEPLOYMENT TYPE ##
################################

try
    {
        write-host "Action: Deleting old deployment type" -ForegroundColor Gray
        Get-CMDeploymentType -ApplicationName $ApplicationName | 
            where {$_.LocalizedDisplayName -like "Old*"} |
            Remove-CMDeploymentType -Force
    }
catch {Write-Warning "An error occurred deleting the old deployment type. $($_.Exception.Message)"}



##################################################
## SET DUMMY REQUIREMENT ON OLD DEPLOYMENT TYPE ##
##################################################

$app = Get-SCCMApplication $ApplicationName "localhost"

# Get DT for rule
$i = -1
do
  {
    $i = $i + 1
    $AppDT = $app.DeploymentTypes[$i].Title
  }
until ($AppDT -like "Java*")

try
    {
        $rule = Create-SCCMGlobalConditionsRule . "TotalPhysicalMemory" "LessThan" 10000000 "CIM"
    }
catch {Write-Warning "An error occurred creating the dummy requirement rule: $($_.Exception.Message)" }

if($rule -ne $null)
  { 
    try
        {
            Write-host "Action: Disabling old deployment type with dummy requirement" -ForegroundColor Gray
            $app.DeploymentTypes[$i].Requirements.Clear() 
            $app.DeploymentTypes[$i].Requirements.Add($rule)
        }
    catch {Write-Warning "An error occurred adding a dummy requirement rule to the old deployment type: $($_.Exception.Message)" }
  }
else {Write-Warning "An error occurred adding a dummy requirement rule to the old deployment type"}

Save-SCCMApplication $app



################################
## RENAME OLD DEPLOYMENT TYPE ##
################################


write-host "Action: Renaming old Java deployment type" -ForegroundColor Gray
$dpt = (Get-CMDeploymentType -ApplicationName $ApplicationName | where {$_.LocalizedDisplayName -like "Java*"}).LocalizedDisplayName
try
    {
        Set-CMDeploymentType -ApplicationName $ApplicationName -DeploymentTypeName $dpt -NewDeploymentTypeName "Old_$DPT"
    }
catch {Write-Warning "An error occurred renaming the old deployment type: $($_.Exception.Message)" }



###############################################
## SET DEPLOYMENT DEADLINE TO DISTANT FUTURE ##
###############################################

try
    {
        Write-Host "Action: Setting the deployment deadline into the distant future" -ForegroundColor Gray
        Set-CMApplicationDeployment -ApplicationName $ApplicationName -CollectionName $TargetedCollection -DeadlineDate 01/01/2099 -DeadlineTime 23:10
    }
catch {Write-Warning "An error occurred setting the deployment deadline date into the future: $($_.Exception.Message)"}
#endregion



#region Download Binaries


###########################
## DOWNLOAD NEW BINARIES ##
###########################

# Get current installer download link
Write-Host "Action: Finding latest Java version" -ForegroundColor Gray
try
    {
        if ($x64)
            {
                # Java 64-bit Offline
                $URL = (invoke-webrequest “http://www.java.com/en/download/manual.jsp” -UserAgent "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36").Links | 
                    Where {$_.innerHTML -like "Windows Offline*64*"} | 
                    Select -expandProperty href
            }
        Else
            {
                # Java 32-bit Offline
                $URL = (invoke-webrequest “http://www.java.com/en/download/manual.jsp” -UserAgent "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36").Links | 
                    Where {$_.innerHTML -like "Windows Offline"} | 
                    Select -expandProperty href
            }
    }
catch
    {Write-Warning "An error occurred finding the latest Java version. Cannot continue. $($_.Exception.Message)"; break}

# Get file name
try
    {
        $request = [System.Net.WebRequest]::Create($url)
        $request.AllowAutoRedirect=$false
        $response=$request.GetResponse()
        $location = $response.GetResponseHeader("Location")
        $FileName = [System.IO.Path]::GetFileName("$location")
        $file = $FileName.split("&")[0]
    }
catch
    {Write-Warning "An error getting the filename for the latest Java version.  Cannot continue. $($_.Exception.Message)"; break}

# Check if binary is already downloaded
$script:majorversion = $file.TrimStart("jre-").Split('-')[0].Split("u")[0]
$script:minorversion = $File.split('u')[1].split('-')[0]
if ($x64)
    {
        if (Get-ChildItem $JavaPackagesourceLocal\jre1.$majorversion.0_$minorversion`_x64 -ErrorAction Ignore)
            {$Downloaded = $true; write-host "Info: Binary is already downloaded" -ForegroundColor Gray}
    }
Else
    {
        if (Get-ChildItem $JavaPackagesourceLocal\jre1.$majorversion.0_$minorversion -ErrorAction Ignore)
            {$Downloaded = $true; write-host "Info: Binary is already downloaded" -ForegroundColor Gray}
    }

# Download file
if (!$Downloaded)
    {
        write-Host "Action: Downloading $file" -ForegroundColor Gray
        $startDTM = (Get-Date)
        try
            {
                Invoke-WebRequest $url -OutFile "$env:userprofile\Downloads\$file"
            }
        catch
            {Write-Warning "An error occurred downloading the latest Java version.  Cannot continue. $($_.Exception.Message)"; break}
        $endDTM = (Get-Date)
        write-host "Info: Download completed in $(($endDTM-$startDTM).minutes) minutes and $(($endDTM-$startDTM).seconds) seconds" -ForegroundColor Gray
    }

#endregion



#region Extract and copy binaries


###########################################
## EXTRACT MSI AND COPY TO PACKAGESOURCE ##
###########################################

$extractionpath = "$env:userprofile\Appdata\LocalLow\Oracle\Java"

if ($Downloaded)
    {
        try
            {
                if ($x64)
                    {
                        $extractfulldirectory = (Get-ChildItem $extractionpath -Filter "*$minorversion`_x64").FullName
                        $extractdirectory = (Get-ChildItem $extractionpath -Filter "*$minorversion`_x64").Name
                    }
                Else
                    {
                        $extractfulldirectory = (Get-ChildItem $extractionpath -Filter "*$minorversion").FullName
                        $extractdirectory = (Get-ChildItem $extractionpath -Filter "*$minorversion").Name
                    }
            }
        catch
            {Write-Warning "An error occurred locating the extracted Java files. Cannot continue. $($_.Exception.Message)"; break}
    }

if (!$Downloaded)
    {
        $javaexe = "$env:userprofile\Downloads\$file"
        $processname = $file.TrimEnd(".exe")

        # run the Java exe to extract the files, then kill the process
        Write-Host "Action: Extracting files" -ForegroundColor Gray
        write-host "Please IGNORE the Java installation window if it appears!" -ForegroundColor Yellow
        try
            { Start-Process $javaexe }
        catch
            { Write-Warning "An error occurred starting the Java executable. Cannot continue. $($_.Exception.Message)"; break }
        do 
            { Start-Sleep -Seconds 30 }
        while ((Get-Process -Name $processname) -eq $null)
        try
            { (Get-Process -Name $processname).Kill() }
        catch
            { Write-Warning "Could not kill the Java executable process. $($_.Exception.Message)" }

        # Copy extracted files from temp directory to packagesource
        Write-Host "Action: Copying extracted files to packagesource" -ForegroundColor Gray
        try
            {
                if ($x64)
                    {
                        $extractfulldirectory = (Get-ChildItem $extractionpath -Filter "*$minorversion`_x64").FullName
                        $extractdirectory = (Get-ChildItem $extractionpath -Filter "*$minorversion`_x64").Name
                    }
                Else
                    {
                        $extractfulldirectory = (Get-ChildItem $extractionpath -Filter "*$minorversion").FullName
                        $extractdirectory = (Get-ChildItem $extractionpath -Filter "*$minorversion").Name
                    }
            }
        catch
            {Write-Warning "An error occurred locating the extracted Java files. Cannot continue. $($_.Exception.Message)"; break}
        try
            {
                Copy-Item $extractfulldirectory $JavaPackageSourceLocal -Recurse -Force
            }
        catch
            {Write-Warning "An error occurred copying the extracted Java files to the SCCM packagesource. Cannot continue. $($_.Exception.Message)"; break}
    }
#endregion



#region New Deployment Type...


################################
## CREATE NEW DEPLOYMENT TYPE ##
################################

$msi = (Get-ChildItem $JavaPackagesourceLocal\$extractdirectory -Filter *.msi).Name

try
    {
        Write-Host "Action: Creating new deployment type" -ForegroundColor Gray
        if ($x64)
            {
                $params = @{
                    MsiInstaller = $True
                    ApplicationName = $ApplicationName
                    ForceForUnknownPublisher = $True
                    InstallationFileLocation = "$JavaPackageSourceRemote\$extractdirectory\$msi"
                    InstallationBehaviorType = "InstallForSystem"
                    InstallationProgram = "msiexec /i $msi /qn REBOOT=ReallySuppress"
                    OnSlowNetworkMode = "Download"
                    AllowClientsToUseFallbackSourceLocationForContent = $true
                    }
            }
        else
            {
                $params = @{
                    MsiInstaller = $True
                    ApplicationName = $ApplicationName
                    ForceForUnknownPublisher = $True
                    InstallationFileLocation = "$JavaPackageSourceRemote\$extractdirectory\$msi"
                    InstallationBehaviorType = "InstallForSystem"
                    InstallationProgram = "msiexec /i $msi /qn REBOOT=ReallySuppress"
                    OnSlowNetworkMode = "Download"
                    AllowClientsToUseFallbackSourceLocationForContent = $true
                    RunInstallationProgramAs32BitProcessOn64BitClient = $true
                    }
            }
        Add-CMDeploymentType @params | out-null
    }
catch
    {Write-Warning "An error occurred creating the new deployment type.  Cannot continue. $($_.Exception.Message)"; break}



##################################
## UPDATE NEW DEPLOYMENT TYPE 1 ##
##################################

# Set the Estimage installation time
# Set the Maximum run time
# Set the Logon Requirement Type if not already set

$script:newdpt = (Get-CMDeploymentType -ApplicationName $ApplicationName | where {$_.LocalizedDisplayName -like "*$minorversion*"}).LocalizedDisplayName

try
    {
        Write-Host "Action: Updating new deployment type" -ForegroundColor Gray
        $params = @{
            MsiOrScriptInstaller = $true
            ApplicationName = $ApplicationName
            DeploymentTypeName = $newdpt
            EstimatedInstallationTimeMinutes = 5
            MaximumAllowedRunTimeMinutes = 30
            LogonRequirementType = "WhetherOrNotUserLoggedOn"
            }
        Set-CMDeploymentType @params
    }
catch
    {Write-Warning "An error occurred updating the new deployment type: $($_.Exception.Message)"}



##################################  
## UPDATE NEW DEPLOYMENT TYPE 2 ##
##################################

# Update detection method script with new Java version code
# Add MSI Product code
# Add a dependency to the UNINSTALL or PREPARE (64-bit) DT

try
   {
     Write-Host "Action: Performing additional deployment type updates" -ForegroundColor Gray
     AdditionalAppUpdates
   }
catch
   {Write-Warning "An error occurred performing additional updates to the new deployment type. $($_.Exception.Message)"}


   
######################################
## REORDER DEPLOYMENT TYPE PRIORITY ##
######################################

do
    {
        try
            {
                Write-Host "Action: Re-ordering deployment type priorities" -ForegroundColor Gray
                Re-OrderDTPriority | Out-null
            }
        catch
            {Write-Warning "An error occurred changing the deployment type priorities. $($_.Exception.Message)"}
    }
while ((Get-CMDeploymentType -ApplicationName $ApplicationName | where {$_.LocalizedDisplayName -like "*$minorversion*"}).PriorityInLatestApp -ne 1)


 #endregion
 

 
#################################
## SET NEW DEPLOYMENT DEADLINE ##
#################################

try
    {
        Write-Host "Action: Setting new deployment deadline" -ForegroundColor Gray
        Set-CMApplicationDeployment -ApplicationName $ApplicationName -CollectionName $TargetedCollection -DeadlineDate $DeployDeadlineDate -DeadlineTime $DeployDeadlineTime
    }
catch {Write-Warning "An error occurred setting the new deployment deadline: $($_.Exception.Message)"}
