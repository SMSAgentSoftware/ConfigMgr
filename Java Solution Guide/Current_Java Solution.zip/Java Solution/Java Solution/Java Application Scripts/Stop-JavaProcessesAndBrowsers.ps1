﻿<#

This script will stop any running Java-related processes, and close web browsers.
Used for Java x64 deployment

#>

$Browsers = "iexplore","firefox","chrome" 
$ErrorActionPreference = "Stop"

# Kill Java processes
try
    {Get-Process | Select ProcessName,Description | Where {$_.Description -like '*Java*'} | Stop-Process -Force -Verbose}
catch
    {$_.Exception.Message}
  
# Kill Browsers
foreach ($browser in $browsers)
    {
        try
            {Get-Process -Name $browser | Stop-Process -Force -Verbose}
        catch
            {$_.Exception.Message}
    }
