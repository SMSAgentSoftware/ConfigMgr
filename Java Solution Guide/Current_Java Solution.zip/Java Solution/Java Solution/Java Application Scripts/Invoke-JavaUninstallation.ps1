﻿<#
JAVA UNINSTALL SCRIPT

This script will do the following things:
    1. Kill any running java-related processes
    2. Kill any open browsers (specified in the $browsers variable)
    3. Uninstall any version of Java
    4. During the uninstallation, if there is a popup that "the specified module could not be found", it will be killed so that the uninstallation can continue and complete
    5. Remove some 'left-over' Java registry keys and directories that can cause installations to fail
    6. Trigger the 'Application Deployment Evaluation Cycle' so that if a desired version of Java was uninstalled, ConfigMgr client will detect it and reinstall it, if it is still deployed to the machine
#>


$Browsers = "iexplore","firefox","chrome" 

$ErrorActionPreference = "Stop"

# Kill Java processes
try
    { Get-Process | Select ProcessName,Description | Where {$_.Description -like '*Java*'} | Stop-Process -Force -Verbose }
catch
    { $_.Exception.Message }
  

# kill Browser processes
foreach ($browser in $browsers)
    {
        try
            { Get-Process -Name $browser | Stop-Process -Force -Verbose }
        catch
            { $_.Exception.Message }
    }


# Search for and uninstall old Java versions
$RegLocations = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall","HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
foreach ($location in $RegLocations)
    {
        if (test-path $location)
            {
                $InstalledJava = @(Get-ChildItem "$location" -Recurse | ForEach-Object { Get-ItemProperty $_.pspath } |
                # Search only for Java RE by excluding any development kits or the auto updater (-and $_.DisplayVersion -gt "$JavaMinVersion")
                Where-Object {$_.DisplayName -match "Java " -and $_.DisplayName -notmatch "Development" -and $_.DisplayName -notmatch "Auto"} | Select DisplayName,DisplayVersion,PSChildName)
                write-host "Found the following Java versions installed:"
                foreach ($java in $InstalledJava)
                    { $java.DisplayName }
                foreach ($java in $InstalledJava)
                    {
                        $MSICode = $java.PSChildName
                        try
                            {
                                write-host "Uninstalling "$java.Displayname
                                Start-Job -Name $java.DisplayName -ArgumentList $MSICode -ScriptBlock `
                                    { 
                                        param($MSICode)
                                        Start-Process -FilePath msiexec.exe -ArgumentList "/x $MSICode /qn REBOOT=ReallySuppress" -Wait -NoNewWindow
                                    }
                                Wait-job -Name $java.DisplayName -Timeout 20 | Out-null
                                $Timeout = 0
                                while (1)
                                    {
                                        if ((Get-Job -name $java.DisplayName).State -eq 'Completed')
                                            { break }
                                        Else 
                                            {
                                                Get-Process rundll32 -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
                                                Start-Sleep -Seconds 5
                                                $Timeout += 5
                                                if ($timeout -ge 20)
                                                    {
                                                        write-host "Gave up waiting for rundll32.exe to exit"
                                                        break
                                                    }
                                            }
                                        Wait-Job -Name $java.DisplayName -Timeout 5 | out-null
                                    }
                                Remove-Job -Name $java.DisplayName
                            }
                        catch
                            { $_.Exception.Message }
                    }
            }
    }


# Remove some registry keys and directories that can cause install problems, or failure of the DT detection method
$JavaLocations = `
  "$env:ProgramFiles\Java", `
  "${env:ProgramFiles(x86)}\Java", `
  "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Java", `
  "HKLM:\SOFTWARE\JavaSoft\Java Runtime Environment\", `
  "HKLM:\SOFTWARE\Wow6432Node\JavaSoft\Java Runtime Environment\"

foreach ($Location in $JavaLocations)
    {
        if (test-path $location)
        {
            try
                {
                    Remove-Item $location -Recurse -Force
                }
            catch
                { $_.Exception.Message }   
        }
    }


# Remove some more reg keys in the HKCR and HKLM
New-PSDrive -PSProvider registry -Name HKCR -Root HKEY_CLASSES_ROOT | Out-Null
try
    {
        Get-ChildItem "HKCR:\Installer\Products" | Where-Object {$_.PSChildName -like "4EA42A62D9304AC4784BF*"} | Select PSPath | Remove-Item -Recurse -Force
        Get-ChildItem "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall" | Where-Object {$_.PSChildName -like "{26A24AE4-*"} | Select PSPath | Remove-Item -Recurse -Force
        Get-ChildItem "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" | Where-Object {$_.PSChildName -like "{26A24AE4-*"} | Select PSPath | Remove-Item -Recurse -Force
    }
catch
    { $_.Exception.Message }  


# Trigger Application Deployment Evaluation Cycle ( to reinstall any Java versions intentionally deployed to this machine, that may have been uninstalled by this script )
$strAction = "{00000000-0000-0000-0000-000000000121}" # Application Deployment Evaluation Cycle
try
    {
        $WMIPath = "\\" + $env:COMPUTERNAME + "\root\ccm:SMS_Client" 
        $SMSwmi = [wmiclass] $WMIPath 
        [Void]$SMSwmi.TriggerSchedule($strAction)
    }
catch
    { $_.Exception.Message }  