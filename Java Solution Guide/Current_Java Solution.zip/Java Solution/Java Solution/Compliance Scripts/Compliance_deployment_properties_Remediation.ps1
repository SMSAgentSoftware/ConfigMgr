﻿# "Deployment.properties Content" Remediation Script

$list = "deployment.javaws.autodownload=NEVER
deployment.javaws.autodownload.locked
deployment.expiration.check.enabled=FALSE"
try
  {
  $list | Out-file C:\Windows\Sun\Java\Deployment\deployment.properties -Encoding ASCII -Force
  }
catch
  {$_}