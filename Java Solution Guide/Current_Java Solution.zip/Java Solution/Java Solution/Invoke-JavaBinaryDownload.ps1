﻿<#
Downloads and extracts the latest Java binaries
#>

[CmdletBinding(SupportsShouldProcess=$True)]
    param
        (
        [Parameter(Mandatory=$False)]
            [ValidateSet("32-bit","64-bit")]$Architecture="32-bit",
        [Parameter(Mandatory=$False)]
            [string]$DownloadLocation="$env:userprofile\Downloads"
        )
      

# Get current installer download link
write-host "Finding latest Java version..."
try
    {
        if ($Architecture -eq "32-bit")
            {
                # Java 32-bit Offline
                $URL = (invoke-webrequest “http://www.java.com/en/download/manual.jsp” -UserAgent "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36").Links | 
                    Where {$_.innerHTML -like "Windows Offline"} | 
                    Select -expandProperty href
            }
        if ($Architecture -eq "64-bit")
            {
                # Java 64-bit Offline
                $URL = (invoke-webrequest “http://www.java.com/en/download/manual.jsp” -UserAgent "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36").Links | 
                    Where {$_.innerHTML -like "Windows Offline*64*"} | 
                    Select -expandProperty href
            }
    }
catch
    {$_.Exception.Message; break}


# Get file name
try
    {
        $request = [System.Net.WebRequest]::Create($url)
        $request.AllowAutoRedirect=$false
        $response=$request.GetResponse()
        $location = $response.GetResponseHeader("Location")
        $FileName = [System.IO.Path]::GetFileName("$location")
        $file = $FileName.split("&")[0]
    }
catch
    {$_.Exception.Message; break}


# Download file
write-host "Downloading $file"
$startDTM = (Get-Date)
try
    {
        Invoke-WebRequest $url -OutFile "$DownloadLocation\$file" -Verbose
    }
catch
    {$_.Exception.Message; break}
$endDTM = (Get-Date)
write-host "Download completed in $(($endDTM-$startDTM).minutes) minutes and $(($endDTM-$startDTM).seconds) seconds"


# Extract and copy binaries
$javaexe = "$DownloadLocation\$file"
#$majorversion = $file.TrimStart("jre-").Split('-')[0]
$script:minorversion = $File.split('u')[1].split('-')[0]
$processname = $file.TrimEnd(".exe")
$extractionpath = "$env:userprofile\Appdata\LocalLow\Sun\Java"


# Run the Java exe to extract the files, then kill the process
write-host "Extracting files...(IGNORE the popup!)"
try
    {
        Start-Process $javaexe
    }
catch
    {$_.Exception.Message; break}
do 
    {
        Start-Sleep -Seconds 8
    }
while ((Get-Process -Name $processname) -eq $null)
try
    {
        (Get-Process -Name $processname).Kill()
    }
catch
    {$_.Exception.Message; write-host "Could not kill the Java executable!"}


# Copy extracted files from temp directory to packagesource
write-host "Opening extracted directory"
try
    {
        if ($Architecture -eq "32-bit")
            {
                $extractfulldirectory = (Get-ChildItem $extractionpath -Filter "*$minorversion").FullName
            }
        if ($Architecture -eq "64-bit")
            {
                $extractfulldirectory = (Get-ChildItem $extractionpath -Filter "*$minorversion`_x64").FullName
            }
    }
catch
    {$_.Exception.Message; write-host "Could not find the extracted Java files!"; break}

Invoke-Item $extractfulldirectory