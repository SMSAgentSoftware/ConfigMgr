﻿## Enter the version code of the current Java deployment.  Keep this updated for any new Java deployments ##
$CurrentVersion = "1.8.0_45"
$Browsers = "iexplore","firefox","chrome" 

$path = "HKLM:\SOFTWARE\JavaSoft\Java Runtime Environment"
$BrowserRunning = 0
# Check if current version is installed
if ((test-path "$path\$CurrentVersion") -eq $true)
    {$CurrentVersionInstalled = $True}
# Check for any running Java processes
if ((Get-Process | Select ProcessName,Description | Where {$_.Description -like '*Java*'}) -ne $null)
    {$JavaRunning = $True}
# Check for any running browsers
foreach ($browser in $Browsers)
    {
        if ((Get-Process -Name $browser -ErrorAction SilentlyContinue) -ne $null)
            {$BrowserRunning ++}
    }
# Current Java version installed?  Compliant
If ($CurrentVersionInstalled -eq $true)
    {write-host "Compliant"}
# No Java app or browser running?  Compliant
If ($JavaRunning -ne $true -and $BrowserRunning -eq 0)
    {write-host "Compliant"}
# Otherwise not compliant
If ($JavaRunning -eq $true -or $BrowserRunning -ge 1)
  {}